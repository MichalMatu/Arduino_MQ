# Agent brief: Arduino Uno + LCD 12864B-V2.3 + MQ-2/MQ-7/MQ-9

Build firmware in VS Code + PlatformIO for an Arduino Uno-compatible ATmega328P board.

## Hardware to use in v1

- Arduino Uno-compatible clone, ATmega328P, 5 V logic.
- LCD 12864B-V2.3, likely ST7920-compatible 128x64 graphical LCD.
- MQ-2, MQ-7 and MQ-9 gas sensor modules on blue Flying-Fish boards.

## Hardware not to use in v1

- SIM800L EVB v2.0 GSM module.
- nRF24L01+ 2.4 GHz radio modules.
- OpenLog microSD logger.

## Firmware behavior

- Read MQ-2/MQ-7/MQ-9 from A0/A1/A2.
- Show raw ADC values and voltages on the LCD.
- Print CSV to USB Serial Monitor at 115200 baud.
- Do not calculate ppm in v1. These modules are wired as simple MQ modules and MQ-7/MQ-9 heater cycles are not controlled.
- Use U8g2 with a page-buffer constructor, not a full-buffer constructor, because Arduino Uno has little RAM.

## PlatformIO

Use the included `platformio.ini` and `src/main.cpp`.

Commands:

```bash
pio run
pio run -t upload
pio device monitor -b 115200
```

## Wiring summary

- LCD `PSB` must go to `GND` for serial mode.
- LCD `RS` -> D10, `R/W` -> D11, `E` -> D13, `RST` -> D8.
- MQ-2 AO -> A0, MQ-7 AO -> A1, MQ-9 AO -> A2.
- All modules use common GND.
