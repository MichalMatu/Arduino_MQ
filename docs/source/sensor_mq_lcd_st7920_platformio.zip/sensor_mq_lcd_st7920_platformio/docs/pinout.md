# Pinout v1

## Final hardware set

- Arduino Uno-compatible board with ATmega328P.
- LCD 12864B-V2.3, most likely ST7920-compatible, 128x64, 20-pin, 5 V.
- MQ-2, MQ-7 and MQ-9 gas sensor modules on blue Flying-Fish boards.

SIM800L GSM, nRF24L01+ radio and OpenLog are not used in v1.

## LCD 12864B-V2.3 to Arduino Uno

Use serial mode. Tie LCD `PSB` to `GND`.

| LCD pin | LCD label | Arduino Uno | Notes |
|---:|---|---|---|
| 1 | GND / VSS | GND | common ground |
| 2 | VCC / VDD | 5V | logic supply |
| 3 | V0 / VO | contrast circuit | use onboard VR1 first; do not tie directly to 5V |
| 4 | RS | D10 | U8g2 `cs` |
| 5 | R/W | D11 | U8g2 `data`, SID in serial mode |
| 6 | E | D13 | U8g2 `clock`, SCLK in serial mode |
| 7-14 | DB0-DB7 | not connected | unused in serial mode |
| 15 | PSB | GND | selects serial mode |
| 16 | NC | not connected | leave open |
| 17 | RST | D8 | reset controlled by code |
| 18 | VOUT | contrast only | negative contrast output; do not use as supply |
| 19 | BLA | 5V | backlight anode; use 100 ohm in series if unsure |
| 20 | BLK | GND | backlight cathode |

## MQ sensors to Arduino Uno

Use only analog output `AO`. Leave `DO` disconnected.

| Sensor | Module pin | Arduino Uno |
|---|---|---|
| MQ-2 | AO | A0 |
| MQ-7 | AO | A1 |
| MQ-9 | AO | A2 |
| all MQ | VCC | 5V |
| all MQ | GND | GND |
| all MQ | DO | not connected |

Read the silk-screen labels on each module before wiring; do not trust physical left-to-right order from a photo.
