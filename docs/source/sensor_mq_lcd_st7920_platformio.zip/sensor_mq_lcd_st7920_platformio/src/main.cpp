#include <Arduino.h>
#include <U8g2lib.h>

// Project v1 hardware:
// Arduino Uno-compatible ATmega328P board + LCD 12864B-V2.3 + MQ-2/MQ-7/MQ-9.
// The SIM800L GSM, nRF24L01+ radio and OpenLog are intentionally not used in v1.
//
// LCD 12864B-V2.3 is wired as a ST7920-compatible 128x64 display in serial mode:
//   LCD PSB -> GND
//   U8g2 ST7920 SW-SPI constructor order:
//     clock -> LCD E
//     data  -> LCD R/W, also called SID in serial mode
//     cs    -> LCD RS, also called CS in serial mode
//     reset -> LCD RST

#ifndef SERIAL_MONITOR_BAUD
#define SERIAL_MONITOR_BAUD 115200
#endif

constexpr uint8_t PIN_LCD_E   = 13;  // LCD pin 6 E / SCLK
constexpr uint8_t PIN_LCD_RW  = 11;  // LCD pin 5 R/W / SID
constexpr uint8_t PIN_LCD_RS  = 10;  // LCD pin 4 RS / CS
constexpr uint8_t PIN_LCD_RST = 8;   // LCD pin 17 RST

constexpr uint8_t PIN_MQ2 = A0;
constexpr uint8_t PIN_MQ7 = A1;
constexpr uint8_t PIN_MQ9 = A2;

constexpr uint16_t ADC_MAX = 1023;
constexpr uint16_t VREF_MV = 5000;
constexpr uint8_t SAMPLES_PER_READING = 16;
constexpr unsigned long SAMPLE_INTERVAL_MS = 1000UL;
constexpr unsigned long DISPLAY_INTERVAL_MS = 1000UL;
constexpr unsigned long WARMUP_NOTICE_MS = 5UL * 60UL * 1000UL;

U8G2_ST7920_128X64_1_SW_SPI u8g2(
    U8G2_R0,
    PIN_LCD_E,
    PIN_LCD_RW,
    PIN_LCD_RS,
    PIN_LCD_RST
);

struct SensorState {
  const char* label;
  uint8_t pin;
  uint16_t raw;
  uint16_t mv;
};

SensorState sensors[] = {
    {"MQ-2", PIN_MQ2, 0, 0},
    {"MQ-7", PIN_MQ7, 0, 0},
    {"MQ-9", PIN_MQ9, 0, 0},
};

constexpr size_t SENSOR_COUNT = sizeof(sensors) / sizeof(sensors[0]);
unsigned long lastSampleMs = 0;
unsigned long lastDisplayMs = 0;

uint16_t rawToMillivolts(uint16_t raw) {
  return static_cast<uint16_t>((static_cast<uint32_t>(raw) * VREF_MV) / ADC_MAX);
}

uint16_t readAveragedAnalog(uint8_t pin) {
  uint32_t sum = 0;
  for (uint8_t i = 0; i < SAMPLES_PER_READING; ++i) {
    sum += analogRead(pin);
    delay(2);
  }
  return static_cast<uint16_t>(sum / SAMPLES_PER_READING);
}

void readSensors() {
  for (size_t i = 0; i < SENSOR_COUNT; ++i) {
    sensors[i].raw = readAveragedAnalog(sensors[i].pin);
    sensors[i].mv = rawToMillivolts(sensors[i].raw);
  }
}

void printCsvHeader() {
  Serial.println(F("time_ms,mq2_raw,mq2_mv,mq7_raw,mq7_mv,mq9_raw,mq9_mv"));
}

void logCsv(unsigned long nowMs) {
  Serial.print(nowMs);
  for (size_t i = 0; i < SENSOR_COUNT; ++i) {
    Serial.print(',');
    Serial.print(sensors[i].raw);
    Serial.print(',');
    Serial.print(sensors[i].mv);
  }
  Serial.println();
}

void drawSensorRow(size_t index, uint8_t y) {
  char line[28];
  const SensorState& sensor = sensors[index];
  const uint16_t volts = sensor.mv / 1000;
  const uint16_t decimals = sensor.mv % 1000;

  snprintf(
      line,
      sizeof(line),
      "%-4s %4u %u.%03uV",
      sensor.label,
      sensor.raw,
      volts,
      decimals
  );

  u8g2.drawStr(0, y, line);

  const uint8_t barMaxWidth = 32;
  const uint8_t barWidth = static_cast<uint8_t>(
      (static_cast<uint32_t>(sensor.raw) * barMaxWidth) / ADC_MAX
  );

  u8g2.drawFrame(94, y - 7, barMaxWidth + 2, 7);
  u8g2.drawBox(95, y - 6, barWidth, 5);
}

void drawScreen(unsigned long nowMs) {
  char text[24];

  u8g2.firstPage();
  do {
    u8g2.setFont(u8g2_font_5x7_tf);
    u8g2.drawStr(0, 7, "MQ sensor monitor");

    snprintf(text, sizeof(text), "t=%lus", nowMs / 1000UL);
    u8g2.drawStr(84, 7, text);

    drawSensorRow(0, 22);
    drawSensorRow(1, 36);
    drawSensorRow(2, 50);

    if (nowMs < WARMUP_NOTICE_MS) {
      const unsigned long remain = (WARMUP_NOTICE_MS - nowMs) / 1000UL;
      snprintf(text, sizeof(text), "warm-up %lus", remain);
    } else {
      snprintf(text, sizeof(text), "RAW ADC - not ppm");
    }
    u8g2.drawStr(0, 63, text);
  } while (u8g2.nextPage());
}

void drawSplash() {
  u8g2.firstPage();
  do {
    u8g2.setFont(u8g2_font_6x10_tf);
    u8g2.drawStr(0, 12, "Arduino Uno + MQ");
    u8g2.drawStr(0, 28, "LCD 12864 ST7920");
    u8g2.setFont(u8g2_font_5x7_tf);
    u8g2.drawStr(0, 48, "Check PSB=GND");
    u8g2.drawStr(0, 60, "Use AO pins only");
  } while (u8g2.nextPage());
}

void setup() {
  Serial.begin(SERIAL_MONITOR_BAUD);
  delay(500);

  analogReference(DEFAULT);
  u8g2.begin();

  drawSplash();
  printCsvHeader();

  readSensors();
  logCsv(millis());
  delay(1200);
}

void loop() {
  const unsigned long nowMs = millis();

  if (nowMs - lastSampleMs >= SAMPLE_INTERVAL_MS) {
    lastSampleMs = nowMs;
    readSensors();
    logCsv(nowMs);
  }

  if (nowMs - lastDisplayMs >= DISPLAY_INTERVAL_MS) {
    lastDisplayMs = nowMs;
    drawScreen(nowMs);
  }
}
